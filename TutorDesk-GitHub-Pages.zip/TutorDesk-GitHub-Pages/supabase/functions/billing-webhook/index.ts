// TUTOR DESK v7 — direct Paddle webhook receiver.
// Verify Paddle's native Paddle-Signature over timestamp + ':' + exact raw request body.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
});
const hex = (bytes: ArrayBuffer) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
async function hmacSha256(secret: string, payload: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payload)));
}
function constantTimeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
function parsePaddleSignature(header: string | null) {
  const parts = new Map<string, string>();
  for (const piece of (header ?? "").split(";")) {
    const i = piece.indexOf("=");
    if (i > 0) parts.set(piece.slice(0, i).trim(), piece.slice(i + 1).trim());
  }
  return { ts: parts.get("ts") ?? "", signatures: (header ?? "").split(";").map(p => p.trim()).filter(p => p.startsWith("h1=")).map(p => p.slice(3)) };
}
function inferPlan(data: any) {
  const monthly = Deno.env.get("PADDLE_PRICE_ID_PRO_MONTHLY");
  const yearly = Deno.env.get("PADDLE_PRICE_ID_PRO_YEARLY");
  const customPlan = data?.custom_data?.tutor_plan_id;
  if (customPlan === "pro_monthly" || customPlan === "pro_yearly") return "pro";
  const items = Array.isArray(data?.items) ? data.items : [];
  if (items.some((item: any) => [monthly, yearly].filter(Boolean).includes(item?.price?.id ?? item?.price_id))) return "pro";
  return null;
}
function mapStatus(status: string) {
  const map: Record<string, string> = { active: "active", trialing: "trialing", past_due: "past_due", canceled: "canceled", paused: "inactive" };
  return map[status] ?? null;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const secret = Deno.env.get("PADDLE_WEBHOOK_SECRET");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!secret || !supabaseUrl || !serviceKey) return json({ error: "server_not_configured" }, 500);

  const raw = await req.text();
  const { ts, signatures } = parsePaddleSignature(req.headers.get("Paddle-Signature"));
  const tsNum = Number(ts);
  // Allow modest clock skew / delivery delay. Event ID deduplication prevents reapplying a replay.
  if (!Number.isFinite(tsNum) || Math.abs(Date.now() / 1000 - tsNum) > 300 || signatures.length === 0) {
    return json({ error: "invalid_or_expired_signature" }, 401);
  }
  const expected = await hmacSha256(secret, `${ts}:${raw}`);
  if (!signatures.some((sig) => constantTimeEqual(sig.toLowerCase(), expected))) return json({ error: "invalid_signature" }, 401);

  let event: any;
  try { event = JSON.parse(raw); } catch { return json({ error: "invalid_json" }, 400); }
  if (!event?.event_id || !event?.event_type || !event?.data) return json({ error: "invalid_event_shape" }, 400);

  // Ignore unrelated Paddle events successfully so Paddle does not retry them forever.
  const supported = new Set(["subscription.created", "subscription.activated", "subscription.updated", "subscription.canceled", "subscription.past_due", "subscription.paused"]);
  if (!supported.has(event.event_type)) return json({ ok: true, ignored: true });

  const data = event.data;
  const userId = data?.custom_data?.tutor_user_id;
  const plan = inferPlan(data);
  const status = mapStatus(String(data?.status ?? ""));
  if (typeof userId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(userId)) {
    return json({ error: "missing_trusted_user_reference" }, 400);
  }
  if (!plan || !status) return json({ error: "unsupported_subscription_state" }, 400);
  const periodEnd = data?.current_billing_period?.ends_at ?? data?.next_billed_at ?? null;
  if (periodEnd !== null && Number.isNaN(Date.parse(periodEnd))) return json({ error: "invalid_period_end" }, 400);

  const admin = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: applied, error } = await admin.rpc("tutor_apply_billing_event", {
    p_provider: "paddle",
    p_provider_event_id: String(event.event_id),
    p_event_type: String(event.event_type),
    p_user_id: userId,
    p_plan: plan,
    p_status: status,
    p_period_end: periodEnd,
    p_provider_customer_id: data?.customer_id ? String(data.customer_id) : null,
    p_provider_subscription_id: data?.id ? String(data.id) : null,
    p_payload: { event_type: String(event.event_type), status: String(data?.status ?? ""), occurred_at: event.occurred_at ?? null },
  });
  if (error) return json({ error: "subscription_update_failed" }, 500);
  return json({ ok: true, result: applied });
});
